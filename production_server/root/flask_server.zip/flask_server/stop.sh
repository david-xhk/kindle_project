#!/bin/bash

# Kill all python3 processes
echo "Stopping Flask server"
sudo pkill -f python3
echo "Stopped Flask server"
